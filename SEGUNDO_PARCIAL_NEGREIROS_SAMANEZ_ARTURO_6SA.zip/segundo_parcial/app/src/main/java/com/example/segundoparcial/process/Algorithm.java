package com.example.segundoparcial.process;

import java.util.ArrayList;
import java.util.Arrays;


/**
 * @author Arturo Negreiros Samanez 6to SA
 *
 *
 * */
public class Algorithm {

    /**
     * @param word This param is from the Main activity
     *             change to String[] and add to Arraylist because in Andoid the first element
     *             For any reason is null
     * */
    public String toChangeWord(String word){

        try {


            ArrayList<String> vectors = new ArrayList<>();
            ArrayList<String> newVectorFinal = new ArrayList<>();

            String [] separatedWords = word.split("");
            String newString = "";

            for (int x = 1;x < separatedWords.length; x++){
                vectors.add(separatedWords[x]);
                newVectorFinal.add(separatedWords[x].toUpperCase());
            }
            ArrayList<String> toConvert = vectors;
            int sizeVector = vectors.size();

            if (sizeVector%2 == 0){
                for (int i = 0; i < sizeVector-1; i+=2){

                    if ( !vectors.get(i).equals(vectors.get(i+1).toUpperCase()) && !vectors.get(i).equals(vectors.get(i+1).toLowerCase())){
                        newString += vectors.get(i)+vectors.get(i+1);
                    }

                }
            }else{
                for (int i = 0; i < sizeVector-1; i+=2){

                    if ( !vectors.get(i).equals(vectors.get(i+1).toUpperCase()) && !vectors.get(i).equals(vectors.get(i+1).toLowerCase())){
                        newString += vectors.get(i)+vectors.get(i+1);
                    }

                }
                newString += vectors.get(sizeVector - 1);
            }



            return newString;



        }catch (Exception e ){
            e.printStackTrace();
            return "";
        }


        //
    }


}
