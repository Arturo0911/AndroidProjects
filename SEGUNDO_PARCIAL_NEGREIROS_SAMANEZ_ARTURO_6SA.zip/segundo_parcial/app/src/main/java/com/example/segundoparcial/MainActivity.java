package com.example.segundoparcial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.segundoparcial.process.Algorithm;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private EditText idTextTochange;
    private TextView idResultFinal;


    public void onButtonResult(View view){

        Algorithm change = new Algorithm();

        //Toast.makeText(this, idTextTochange.getText().toString(), Toast.LENGTH_SHORT).show();
        Toast.makeText(this, change.toChangeWord(idTextTochange.getText().toString()), Toast.LENGTH_SHORT).show();
        idResultFinal.setText(change.toChangeWord(idTextTochange.getText().toString()));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idTextTochange = (EditText) findViewById(R.id.idTextTochange);
        idResultFinal = (TextView) findViewById(R.id.idResultFinal);

    }
}